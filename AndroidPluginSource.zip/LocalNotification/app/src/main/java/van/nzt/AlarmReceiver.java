package van.nzt;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import static android.app.NotificationManager.IMPORTANCE_DEFAULT;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", 0);
        String title = intent.getStringExtra("title");
        String content = intent.getStringExtra("content");
        String ticker = intent.getStringExtra("ticker");
        String bundleId = context.getPackageName();

        Intent notificationIntent = context.getPackageManager().getLaunchIntentForPackage(bundleId);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addNextIntent(notificationIntent);

        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Big icon
        int bigIconId = context.getResources().getIdentifier("notify_icon_big", "drawable", context.getPackageName());

        if (bigIconId == 0)
            bigIconId = context.getApplicationInfo().icon;

        Bitmap bigIconBitmap = BitmapFactory.decodeResource(context.getResources(), bigIconId);

        // Small icon
        int smallIconId = context.getResources().getIdentifier("notify_icon_small", "drawable", context.getPackageName());

        if (smallIconId == 0)
            smallIconId = context.getApplicationInfo().icon;

        Notification.Builder builder = new Notification.Builder(context);
        Notification notification = builder.setContentTitle(title)
                .setContentText(content)
                .setTicker(ticker)
                .setStyle(new Notification.BigTextStyle().bigText(content))
                .setSmallIcon(smallIconId)
                .setLargeIcon(bigIconBitmap)
                .setContentIntent(pendingIntent).build();

        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        notification.defaults |= Notification.DEFAULT_SOUND;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(bundleId);
        }

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(bundleId, "Local Notification", IMPORTANCE_DEFAULT);

            if (notificationManager != null)
                notificationManager.createNotificationChannel(channel);
        }

        if (notificationManager != null)
            notificationManager.notify(id, notification);
    }
}
